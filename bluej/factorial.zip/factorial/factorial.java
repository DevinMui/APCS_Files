
/**
 * Write a description of class factorial here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class factorial
{
    public static void main(String[] args){
        fact f = new fact();
        System.out.println(f.fact(5));
        
    }
    
}
