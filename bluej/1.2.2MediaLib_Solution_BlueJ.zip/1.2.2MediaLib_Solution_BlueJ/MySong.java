
/**
 * Write a description of class blah here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MySong extends Song
{
    /**
     * Constructor for objects of class blah
     */
    public double showSong() 
    {
 double a = 8.5;
 int b = 19;
 double t = a * b / 100;
        return t;
    }
}
